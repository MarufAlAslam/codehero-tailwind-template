tailwind.config = {
  theme: {
    extend: {
      colors: {
        primary: "#00a8ea",
        blue: "#27367d",
        green: "#9bc31c",
      },
    },
  },
};
